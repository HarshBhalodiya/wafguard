import axios from "axios";

const baseURL =
  import.meta.env.VITE_API_BASE_URL || "http://localhost:8000/api";

export const api = axios.create({
  baseURL,
  timeout: 20000,
  withCredentials: false, // set true only if you use cookie-based sessions
});

// ---------------------------------------------------------------------------
// Interceptor: attach the JWT to every outgoing request.
// Reads the SAME key your login code writes to localStorage.
// If your login uses a different key (e.g. "access_token"), change the
// list below to match. Keep the order so the first existing key wins.
// ---------------------------------------------------------------------------
function getAuthToken() {
  return (
    localStorage.getItem("wafguard_token") ||
    localStorage.getItem("access_token") ||
    localStorage.getItem("token") ||
    null
  );
}

api.interceptors.request.use((config) => {
  const token = getAuthToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// ---------------------------------------------------------------------------
// Optional: centralised 401 handling — redirect to login or clear storage.
// Remove or adapt if your app handles 401 elsewhere.
// ---------------------------------------------------------------------------
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token is missing, expired, or rejected by the backend.
      localStorage.removeItem("wafguard_token");
      localStorage.removeItem("access_token");
      localStorage.removeItem("token");
      // Optionally redirect to your login page:
      // window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

// ---------------------------------------------------------------------------
// Unwraps the { success, data, error, timestamp } envelope every WafGuard
// endpoint returns. Throws a normalised Error with `.code` and `.status`
// so components can branch on error type instead of parsing Axios errors.
// ---------------------------------------------------------------------------
export async function apiRequest(config) {
  try {
    const response = await api.request(config);
    const envelope = response.data;

    if (!envelope.success) {
      const err = new Error(
        envelope.error?.message || "Request failed",
      );
      err.code = envelope.error?.code || "UNKNOWN_ERROR";
      err.status = response.status;
      throw err;
    }

    return envelope.data;
  } catch (caught) {
    if (caught.code) throw caught; // already normalised above

    const envelope = caught.response?.data;
    const err = new Error(
      envelope?.error?.message || caught.message || "Network error",
    );
    err.code = envelope?.error?.code || "NETWORK_ERROR";
    err.status = caught.response?.status;
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Convenience wrappers — preserve the query-parameter and return-type
// conventions your components already expect.
// ---------------------------------------------------------------------------
export const get = (url, params) =>
  apiRequest({ method: "GET", url, params });

export const post = (url, data, config = {}) =>
  apiRequest({ method: "POST", url, data, ...config });